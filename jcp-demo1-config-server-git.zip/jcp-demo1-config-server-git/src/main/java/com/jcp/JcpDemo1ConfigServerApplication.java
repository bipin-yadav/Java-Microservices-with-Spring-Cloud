package com.jcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class JcpDemo1ConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JcpDemo1ConfigServerApplication.class, args);
	}
}
