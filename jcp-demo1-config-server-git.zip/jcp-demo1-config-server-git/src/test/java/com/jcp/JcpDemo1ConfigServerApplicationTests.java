package com.jcp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JcpDemo1ConfigServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
