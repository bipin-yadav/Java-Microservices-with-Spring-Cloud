package com.jcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JcpDemo1ConfigServerGitClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(JcpDemo1ConfigServerGitClientApplication.class, args);
	}
}
